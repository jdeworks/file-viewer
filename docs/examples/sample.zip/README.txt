Hello from a zip archive.
This viewer lists entries without extracting them.
